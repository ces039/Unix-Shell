/* Corrine Smith
 * CSCI 315
 * Lab 7
 * 10/24/17
 */

#include <stdlib.h>
#include <stdio.h>
#include "allocator.h"
#include "dlist.h"
#include "dnode.h"

struct dlist *free_list;
struct dlist *allocated_list;

int allocator_init(size_t size){
	free_list = dlist_create();
	allocated_list = dlist_create();
	void *ptr = malloc(size);
	if(ptr == NULL){
		if(size == 0){
			printf("No memory allocated because size given was 0.");
			return -1;
		}
		printf("ERROR in malloc");
		return -1;
	}
	dlist_add_front(free_list, ptr, size);
	return 0;
}

void *allocate(size_t size){
	int x = (rand() % 3);
	void *ptr;
	if(x == 0){
		ptr = first_fit(size);
	}
	else if(x == 1){
		ptr = best_fit(size);
	}
	else{
		ptr = worst_fit(size);
	}
	dlist_add_back(allocated_list, ptr, size);
	struct mem_args *data = (struct mem_args *) dlist_find_remove(free_list, ptr, size);	
	dlist_add_back(free_list, data->start, data->size);
	return ptr;
}

void *first_fit(size_t size){
	void *ptr = dlist_iter_begin(free_list);
	while(dlist_find_size(free_list, ptr) < size && dlist_iter_has_next(free_list)){
		ptr = dlist_iter_next(free_list);
	}
	if(dlist_find_size(free_list, ptr) >= size){
		return ptr;
	}
	else{
		printf("Requested size too large for current free memory.");
		return NULL;
	}
}

void *worst_fit(size_t size){
	void *ptr = dlist_iter_begin(free_list);
	size_t max_size = dlist_find_size(free_list, ptr);
	void *max = ptr;
	size_t curr_size = max_size;
	while(dlist_iter_has_next(free_list)){
		ptr = dlist_iter_next(free_list);
		curr_size = dlist_find_size(free_list, ptr);
		if(curr_size > max_size){
			max_size = curr_size;
			max = ptr;
		}
	}
	if(max_size >= size){
		return max;
	}
	else{
		printf("Requested size too large for current free memory.");
		return NULL;
	}
}

void *best_fit(size_t size){
	void *ptr = dlist_iter_begin(free_list);
        size_t min_size = dlist_find_size(free_list, ptr);
        void *min = ptr;
        size_t curr_size = min_size;
        while(dlist_iter_has_next(free_list)){
                ptr = dlist_iter_next(free_list);
                curr_size = dlist_find_size(free_list, ptr);
                if(curr_size >= size && curr_size < min_size){
                        min_size = curr_size;
                        min = ptr;
                }
        }
        if(min_size >= size){
                return min;
        }
        else{
                printf("Requested size too large for current free memory.");
                return NULL;
        }
}


int deallocate(void *ptr){
	size_t size = dlist_find_size(allocated_list, ptr);
	void * data = dlist_find_remove(allocated_list, ptr, size);
	if(data == NULL){
		printf("Pointer not allocated");
		return -1;
	}
	dlist_add_back(free_list, ptr, size);
	return 0;
}
