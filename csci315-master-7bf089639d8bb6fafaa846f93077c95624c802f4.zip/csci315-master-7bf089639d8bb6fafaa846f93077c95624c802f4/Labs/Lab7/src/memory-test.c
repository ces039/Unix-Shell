/* Corrine Smith
 * CSCI 315
 * Lab 7
 * 10/24/17
 */

#include <stdlib.h>
#include <stdio.h>
#include "allocator.h"
#include "dlist.h"
#include "dnode.h"

int main(int argc, char*argv[]){
	/*if(argc < 2){
		printf("Please input size of allocated memory");
		return -1;
	}
	size_t size = (size_t) argv[1];*/
	int check = allocator_init(5);
	printf("check = %d\n", check);
	void *ptr = allocate(3);
	printf("pointer: %p\n", ptr);
	void *ptr2 = allocate(1);
	void *ptr3 = allocate(1);
	void *ptr4 = allocate(4);
	deallocate(ptr2);
	deallocate(ptr);
	ptr = allocate(5);
	deallocate(ptr3);
	deallocate(ptr);
	ptr4 = allocate(4);
	deallocate(ptr4);
}
