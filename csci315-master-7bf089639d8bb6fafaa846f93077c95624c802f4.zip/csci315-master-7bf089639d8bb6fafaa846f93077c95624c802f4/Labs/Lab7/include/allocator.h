/* Corrine Smith
 * CSCI 315
 * Lab7
 * 10/24/17
 */

#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include "dlist.h"

struct dlist *free_list;
struct dlist *allocated_list;

int allocator_init(size_t size);

void *allocate(size_t size);

int deallocate(void *ptr);

void *first_fit(size_t size);

void *worst_fit(size_t size);

void *best_fit(size_t size);

#endif /* ALLOCATOR_H */
