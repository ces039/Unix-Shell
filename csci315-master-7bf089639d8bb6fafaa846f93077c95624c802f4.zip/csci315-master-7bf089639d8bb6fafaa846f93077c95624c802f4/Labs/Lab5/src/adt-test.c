/* Corrine Smith
 * CSCI 315
 * Lab 5
 * 9/19/17
 */

#include <stdlib.h>
#include <stdio.h>
#include "circular-list.h"

int main(void){
	struct circular_list l;

	item i;
	item i2;

	item new1 = 0.1;
	item new2 = 0.2;
	item new3 = 0.3;
	item new4 = 0.4;
	item new5 = 0.5;
	item new6 = 0.6;
	
	circular_list_create(&l, 5);

	circular_list_insert(&l, new1);
	circular_list_insert(&l, new2);
	circular_list_insert(&l, new3);
	circular_list_insert(&l, new4);
	circular_list_insert(&l, new5);
	circular_list_insert(&l, new6); //this shouldn't work

	for(int j = 0; j < l.size; j++){
		printf("%f, ", l.buffer[j]);
	}
	printf("\n");

	circular_list_remove(&l, &i);
	printf("%f was removed from the list\n", i);
	circular_list_remove(&l, &i2);
	printf("%f was removed from the list\n", i2);

	for(int j = l.start; j <= l.elems+1; j++){
                printf("%f, ", l.buffer[j]);
        }
        printf("\n");

	return 0;
}
