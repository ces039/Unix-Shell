/*
 * Copyright (c) 2013 Bucknell University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: L. Felipe Perrone (perrone@bucknell.edu)
 */

#include <stdlib.h>
#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
#include "circular-list.h" 

int
circular_list_create(struct circular_list *l, int size) {
  l->buffer = calloc(size, sizeof(item));
  l->start = -1;
  l->end = -1;
  l->elems = 0;
  l->size = size;
  int ret = sem_init(&(l->full), 0, 0);
  int ret2 = sem_init(&(l->empty), 0, size);
  int ret3 = pthread_mutex_init(&(l->mutex), NULL);

  if(ret != 0 || ret2 != 0 || ret3 != 0){
	printf("semaphore or mutex initialization error");
	exit(-1);
  }
  return 0;
}

int
circular_list_insert(struct circular_list *l, item i) {
  	sem_wait(&(l->empty));
  	pthread_mutex_lock(&(l->mutex));
	if(l->elems == l->size){
		printf("List is full. Cannot insert item.\n");
		return 0;
	}
	if(l->elems == 0){
		l->start++;
	}
	int max_size = l->size;
	l->end = (l->end + 1) % max_size;
	l->buffer[l->end] = i;
	l->elems ++;
  	pthread_mutex_unlock(&(l->mutex));
	sem_post(&(l->full));

	return 0;
}

int
circular_list_remove(struct circular_list *l, item *i) {
	sem_wait(&(l->full));
	pthread_mutex_lock(&(l->mutex));

	if(l->elems == 0){
		printf("List is empty. Cannot delete item.");
		return 0;
	}
	int max_size = l->size;
	*i = l->buffer[l->start];
	l->start = (l->start+1) % max_size; 
	l->elems --;
	pthread_mutex_unlock(&(l->mutex));
	sem_post(&(l->empty));
	return 0;
}
