/*
 * Copyright (c) 2013 Bucknell University
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation;
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Author: L. Felipe Perrone (perrone@bucknell.edu)
 */

#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h> 
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>

#include "circular-list.h" 

/* SCALE_FACTOR is a constant for you to experiment with:
 * if you choose a very large SCALE_FACTOR, your threads
 * might spend a long time sleeping. If you choose it to be
 * too small, your threads will not sleep at all. Note
 * that in the producer and consumer functions, the sleep
 * time is computed as the INTEGER DIVISION below:
 *
 *  usleep(SCALE_FACTOR * rand_r(&seed) / RAND_MAX
 *
 *  where RAND_MAX is the largest random numver returned
 *  by rand_r. If the numerator is smaller than RAND_MAX,
 *  the quotient of the integer division is ZERO!
 */
#define SCALE_FACTOR 1000

// global variables -----------------------

struct circular_list mylist;
/*struct thread_args {
  int seed_number;
}*/

// end of global variables ----------------

void *producer (void *param) {
  item i;
  unsigned int seed = 1234;

  while (true) {
    // sleep for random period of time
    int sleep = rand_r((&seed)/*(param->seed_number)*/);
    printf("random sleep producer: %d\n", sleep);
    usleep(SCALE_FACTOR * sleep / RAND_MAX); 
    
    // generate a random number
    i = (item) (((double) rand_r(&seed)/**(seed_number))*/ / RAND_MAX));

    if (circular_list_insert(&mylist, i) == -1) {
      printf("PRODUCER: error condition\n");
    } else {
      printf("PRODUCER: produced value %lf\n", i);
    }
  }
}

void *consumer (void *param) {
  item i;
  unsigned int seed = 999;

  while (true) {
    // sleep for random period of time
    int sleep = rand_r(&seed/**(param->seed_number*/);
    printf("random sleep consumer: %d\n", sleep);
    usleep(SCALE_FACTOR * sleep / RAND_MAX);

    if (circular_list_remove(&mylist, &i) == -1) {
      printf("CONSUMER: error condition\n");
    } else {
      printf("CONSUMER: consumed value %lf\n", i);
    }
  }
}

int main (int argc, char *argv[]) {

  // get command line arguments
  
  // if error in command line argument usage, terminate with helpful
  // message

  if (argc < 4){
        printf("usage: [num_prod] [num_cons] [sleep_time]\n");
        exit(-1);
  }

  int num_prod = atoi(argv[1]);
  int num_cons = atoi(argv[2]);
  int sleep_time = atoi(argv[3]);

  
  // initialize buffer
  circular_list_create(&mylist, 10);
  
  // create producer thread(s)
  pthread_attr_t p_attr;
  pthread_t *p_tidp;
  int p_ret_val;

  pthread_attr_init(&p_attr);

 /* struct thread_args *args = (struct thread_args *) calloc(num_prod, sizeof(struct thread_args));*/

  p_tidp = (pthread_t *) calloc(num_prod, sizeof(pthread_t));

  for (int i=0; i<num_prod; i++){
	//args[i].seed_number = i; 
	p_ret_val = pthread_create(&p_tidp[i], &p_attr, producer, NULL);
	if(p_ret_val){
		printf("ERROR in pthread_create for thread %d: return value= %d\n", i, p_ret_val);
		exit(-1);
	}
  }

  // create consumer thread(s)
  pthread_attr_t c_attr;
  pthread_t *c_tidp;
  int c_ret_val;

  pthread_attr_init(&c_attr);

  c_tidp = (pthread_t *) calloc(num_cons, sizeof(pthread_t));
  /*struct thread_args *cargs = (struct thread_args *) calloc(num_cons, sizeof(struct thread_args));*/

  for (int i=0; i<num_cons; i++){
	//cargs[i].seed_number = i;
        c_ret_val = pthread_create(&c_tidp[i], &c_attr, consumer, NULL);
        if(c_ret_val){
                printf("ERROR in pthread_create for thread %d: return value= %d\n", i, c_ret_val);
		exit(-1);
	}
  }

  // sleep to give time for threads to run
  sleep(sleep_time);
  // exit
  return (0);
}
