/* Corrine Smith
 * CSCI 315
 * Lab 10
 * 11/14/17
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <string.h>
#include <unistd.h>
#include <stdbool.h>

int main(int argc, char *argv[]){
	FILE *file;
	sem_t *channel2;
	char *name = "channel10";
	char *write_msg;


	if(argc != 2){
		return -1;
	}
	channel2 = sem_open(name, O_CREAT, 0600, 0);
	printf("sem opened\n");
	write_msg = argv[1];	
	//strcpy(write_msg, argv[1]);
	printf("write msg: %s\n", write_msg);
	int length = strlen(write_msg);
	printf("length: %d\n", length);
	strcat(write_msg, "\0");
	file = fopen("channel.txt", "a");
	fprintf(file, write_msg);
	sem_post(channel2);
	printf("sem unlocked\n");	
	fclose(file);
	return 0;
}
