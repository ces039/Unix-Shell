/* Corrine Smith
 * CSCI 315
 * Lab 10
 * 11/14/17
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>
#include <unistd.h>

int main(){
	char *name = "channel10";
	sem_t *channel2;
	int fd;
	char read_msg[512];
	printf("attributes good\n");
	channel2 = sem_open(name, O_CREAT, 0600, 0);
	printf("semaphore opened\n");
	//sem_wait(channel2);
	//fd = open("channel.txt", O_RDONLY);
	
	while(true){
		sem_wait(channel2);
		printf("semaphore locked\n");
		fd = open("channel.txt", O_RDONLY);
		printf("file opened\n");
		//fd = open("channel.txt", O_RDONLY);
		//printf("file opened");
		read(fd, read_msg, 512);
		printf("receiver[msg arrival]: \"%s\"\n", read_msg);
		printf("semaphore unlocked\n");
		close(fd);
		printf("file closed\n");
		fflush(stdout);
	}
	return 0;
}
