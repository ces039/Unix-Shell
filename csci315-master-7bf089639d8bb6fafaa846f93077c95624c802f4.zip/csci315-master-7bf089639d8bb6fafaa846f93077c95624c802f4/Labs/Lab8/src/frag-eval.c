/* Corrine Smith
 * CSCI 315
 * Lab 7
 * 10/24/17
 */

#include <stdlib.h>
#include <stdio.h>
#include "allocator.h"
#include "dlist.h"
#include "dnode.h"

int main(int argc, char*argv[]){
	if(argc < 4){
		printf("Please input correct paramters: frag-eval [algorithm] [seed] [requests]");
		return -1;
	}
	int alg = argv[1];
	int seed = argv[2];
	int requests = argv[3];

	size_t size = (size_t) 100;
	int check = allocator_init(size);
	printf("check = %d\n", check);
	void *ptr = allocate(3);
	printf("pointer: %p\n", ptr);
	void *ptr2 = allocate(2, alg);
	void *ptr3 = allocate(3, alg);
	deallocate(ptr2);
	deallocate(ptr);
	ptr = allocate(5, alg);
	deallocate(ptr3);
	deallocate(ptr);
	void *ptr4 = allocate(4, alg);
	deallocate(ptr4);
	return 0;
}
