/* Corrine Smith
 * CSCI315
 * Lab 6 Prelab
 * 10/17/17
 */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <stdbool.h>

unsigned int seed = 0;

struct thread_args {
	int ID;
	pthread_mutex_t *chopsticks;
};


void napping(int t){
	double rand = 1500*(rand_r(&seed)/(float)RAND_MAX);
	int num = ((int)(t*rand))%45;
	seed = num;
        sleep(num);
}


void * Philosopher(void *targs){
	struct thread_args *targ = (struct thread_args*) targs;
	printf("Philosopher %d is thinking.\n", targ->ID);
	
	printf("Philosopher %d is hungry.\n", targ->ID);
	int left_chopstick = targ->ID;
	int right_chopstick = (targ->ID+1)%5;
	bool check = (targ->ID%2 == 0);
        if(check){
                pthread_mutex_lock(&targ->chopsticks[left_chopstick]);
		printf("Philosopher %d is picking up chopstick %d\n", targ->ID, left_chopstick);
		napping(2);
                pthread_mutex_lock(&targ->chopsticks[right_chopstick]);
		printf("Philosopher %d is picking up chopstick %d\n", targ->ID, right_chopstick);
        }
        else{
                pthread_mutex_lock(&targ->chopsticks[right_chopstick]);
		printf("Philosopher %d is picking up chopstick %d\n", targ->ID, right_chopstick);
		napping(2);
                pthread_mutex_lock(&targ->chopsticks[left_chopstick]);
		printf("Philosopher %d is picking up chopstick %d\n", targ->ID, left_chopstick);

        }

	printf("Philosopher %d is starting to eat.\n", targ->ID);
	napping(2);
	printf("Philosopher %d is done eating.\n", targ->ID);
	if(check){
		pthread_mutex_unlock(&targ->chopsticks[right_chopstick]);
		printf("Philosopher %d is putting down chopstick %d\n", targ->ID, right_chopstick);
		napping(1);
		pthread_mutex_unlock(&targ->chopsticks[left_chopstick]);
		printf("Philosopher %d is putting down chopstick %d\n", targ->ID, left_chopstick);
	}
	else{
		pthread_mutex_unlock(&targ->chopsticks[left_chopstick]);
                printf("Philosopher %d is putting down chopstick %d\n", targ->ID, left_chopstick);
		napping(1);
		pthread_mutex_unlock(&targ->chopsticks[right_chopstick]);
                printf("Philosopher %d is putting down chopstick %d\n", targ->ID, right_chopstick);
	}
}

void main(){
	pthread_mutex_t *chopsticks;
        chopsticks = (pthread_mutex_t *) calloc(5, sizeof(pthread_mutex_t));
        int m_ret_val;
	struct thread_args *targs = (struct thread_args *) calloc(5, sizeof(struct thread_args));

        for (int i = 0; i < 5; i++){
		targs[i].ID = i;
		targs[i].chopsticks = chopsticks;
                m_ret_val = pthread_mutex_init(&chopsticks[i], NULL);
                if(m_ret_val != 0){
                        printf("ERROR in pthread_mutex_init for chopstick id %d: return value = %d\n", i, m_ret_val);
	        }
	}
	pthread_attr_t p_attr;
	pthread_t *p_tidp;
	int p_ret_val;	

	pthread_attr_init(&p_attr);

	p_tidp = (pthread_t *) calloc(5, sizeof(pthread_t));

	for (long long i = 0; i < 5; i++){
		p_ret_val = pthread_create(&p_tidp[i], &p_attr, Philosopher, (void *)&targs[i]);
		if(p_ret_val){
			printf("ERROR in pthread_create for thread %d: return value = %d\n", i, p_ret_val);
			exit(-1);
		}
	}
	sleep(360);
	free(p_tidp);
	free(chopsticks);
}
