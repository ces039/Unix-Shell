/* Corrine Smith
 * CSCI315
 * Lab 6 Prelab
 * 10/17/17
 */

#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>


void napping(int t){
	int num = rand_r(&t);
        usleep(1000 * num/ RAND_MAX);
}


void * Philosopher(void *ID){
	printf("Philosopher %d is thinking.\n", ID);
	napping(2);
	printf("Philosopher %d is hungry.\n", ID);
	printf("Philosopher %d is starting to eat.\n", ID);
	napping(1);
	printf("Philosopher %d is done eating.\n", ID);
}

void main(){
	pthread_attr_t p_attr;
	pthread_t *p_tidp;
	int p_ret_val;

	pthread_attr_init(&p_attr);

	p_tidp = (pthread_t *) calloc(5, sizeof(pthread_t));

	for (long long i = 0; i < 5; i++){
		p_ret_val = pthread_create(&p_tidp[i], &p_attr, Philosopher, (void *)i);
		if(p_ret_val){
			printf("ERROR in pthread_create for thread %d: return value = %d\n", i, p_ret_val);
			exit(-1);
		}
	}
	sleep(2);
}
