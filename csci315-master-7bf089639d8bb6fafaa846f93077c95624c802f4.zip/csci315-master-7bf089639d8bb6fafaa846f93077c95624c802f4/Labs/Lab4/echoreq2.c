/*
 * CSCI 315 Operating Systems Design
 * Author: L. Felipe Perrone
 * Date: 2014-09-21
 * Copyright (c) 2014 Bucknell University
 *
 * Permission is hereby granted, free of charge, to any individual
 * or institution obtaining a copy of this software and associated
 * documentation files (the "Software"), to use, copy, modify, and
 * distribute without restriction, provided that this copyright
 * and permission notice is maintained, intact, in all copies and
 * supporting documentation.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL BUCKNELL UNIVERSITY BE LIABLE FOR ANY CLAIM, DAMAGES
 * OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
 * OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE
 * OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <netdb.h>
#include "wrappers.h"

#define BUFFER_SIZE 512
#define TRUE 1
#define FALSE 0

/*------------------------------------------------------------------------
 * Program:   echoreq
 *
 * Purpose:  allocate a socket, connect to a server, transfer requested
 *            file to local host, and print file contents to stdout
 *
 * Usage:    echoreq [ host ] [ port ] [ string ] 
 *
 *		 host  - name of a computer on which server is executing
 *		 port  - protocol port number server is using
 *     string - a string in double quotes
 *     
 *------------------------------------------------------------------------
 */

extern Accept(int sockfd, struct sockaddr *addr, socklen_t *addrlen);
extern Listen(int sockfd, int backlog);
extern Bind(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
extern Connect(int sockfd, const struct sockaddr *addr, socklen_t addrlen);
extern Close(int fd);
extern Open(const char *pathname, int flags);
extern Waitpid(pid_t pid, int *status, int options);
extern Wait(int *status);
extern Write(int fd, const void *buf, size_t count);
extern Read(int fd, void *buf, size_t count);
extern Pipe(int pipefd[2]);
extern Fork(void);
extern Getaddrinfo(const char *node, const char *service, const struct addrinfo *hints, struct addrinfo **res);


int
main(int argc, char* argv[]) {

	struct addrinfo hints;
	memset(&hints, 0, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	struct addrinfo *res;

	int status;
	int	sd;		                 // socket descriptor			
	char *port;		               // protocol port number		
	char *host;                // pointer to host name		
	char  in_msg[BUFFER_SIZE]; // buffer for incoming message

	int ret_val;	

	// verify usage

	if (argc < 4) {
		printf("Usage: %s [ host ] [ port ] [ string ]\n", argv[0]);
		exit(-1);
	}

	host = argv[1];		
	port = argv[2];	

	
	if ((atoi(port)) <= 0) {				
		// print error message and exit	
		printf("ECHOREQ: bad port number %s\n", argv[2]);
		exit(-1);
	}

	// convert host name to equivalent IP address and copy to sad 

	Getaddrinfo(host, port, &hints, &res); 

	if ( ((char *)(host) == NULL )) {
		printf("ECHOREQ: invalid host: %s\n", host);
		exit(-1);
	}

	// create socket 

	sd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
	if (sd < 0) {
		printf("ECHOREQ: socket creation failed\n");
		exit(-1);
	}

	// connect the socket to the specified server 

	if (Connect(sd, (struct sockaddr *)((res->ai_addr)), sizeof(res->ai_addr)) < 0) {
		perror("ECHOREQ: connect failed");
		exit(-1);
	}

	// send message to server
	Write(sd, argv[3], strlen(argv[3]));

	// receive message echoed back by server
	Read(sd, &in_msg, BUFFER_SIZE); 

	printf("ECHOREQ: from server= %s\n", in_msg);

	// close the socket   
	Close(sd);

	// terminate the client program gracefully 
	return(0);
}
