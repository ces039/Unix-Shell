/*Corrine Smith
 * CSCI 315
 * Lab1 Prelab
 * 8/29/17
 * 
 * Note: I assume that the input is given in quotes to avoid the arguement counter being off.
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]){

	if(argc != 2){
		printf("Incorrect number of parameters");
		return 0;
	}
	
	char* str = argv[1];
	char* new_str = malloc(strlen(str));
	int length = strlen(str);	

	for(int i = length -1; i>=0; i--){
		new_str[length-1-i] = str[i];
	}
	
	printf("%s\n", new_str);
	return 0;
}
