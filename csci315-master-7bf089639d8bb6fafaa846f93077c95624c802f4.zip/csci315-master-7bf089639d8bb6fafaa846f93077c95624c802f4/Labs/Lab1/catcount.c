/* Corrine Smith
 * CSCI 315
 * Lab1
 * 9/3/17
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

extern char **environ;

void print_environment(void){
	int i = 0;
	while(environ[i]){
		printf("%s\n", environ[i]);
		i++;
	}
}

int main(int argc, char *argv[]){
	print_environment();

	pid_t pid;
	int status = 0;
	if((pid = fork())==0){
		execlp("cat", "cat", argv[1]);
	}
	else{
		wait(&status);
		if(status ==0){
			if((pid = fork())==0){
				execlp("wc", "wc", argv[1]);
			}
			wait(&status);
		}
		else{
			printf("Child process not terminated normally.");
		}
		exit(0);
	}
}
