/*Corrine Smith
 * CSCI 315
 * Lab 1 Prelab
 * 8/29/17
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/types.h>

int main(){
	pid_t pid;
	int fork_counter = 1;
	
	pid = fork();

	if(pid != 0){	
		int pcount = 1;
		while(true){
			printf("Parent: %d\n", pcount);
			pcount++;
		}
	}
	else{
		
		if(pid = fork()){
			int count1 = 1;
			while(true){
				printf("Child1: %d\n", count1);
				count1++;
			}
		}
		else{
			int count2 = 1;
			while(true){
				printf("Child2: %d\n", count2);
				count2++;
			}
		}
	}
}
/*pid_t Parent(){
 	if(fork_counter <2){
		printf("CREATE CHILD2");
 	        pid_t pid2 = fork();
                fork_counter++;
        }

        int pcount = 1;
        while(true){
                printf("Parent: %d\n", pcount);
                pcount++;
        }
}

void Child(pid_t pid1){
        int count1 =1;
	int count2 =1;
	if(pid1 ==0){
        	while(true){
                	printf("Child1: %d\n", count1);
                	count1++;
		}
	}
	else{
		while(true){
			printf("Child2: %d\n", count2);
			count2++;
		}
	}
}

int main(){
	pid_t pid1;
	pid_t pid2;
	pid1 = fork();
	printf("pid1: %d\n", pid1);

	int fork_counter = 1;
	if(pid1 == 0 || (pid2 && pid2 == 0){
		printf("BEGIN CHILD");
		Child(pid1);
	}
}

	while(true){
		printf("pid1: %d\n", pid1);
		printf("pid2: %d\n", pid2);
		if(pid1 == 0){

			//printf("Child1: %d\n", count1);
			count1++;
		}
		else if(pid2 && pid2 == 0){
			//printf("Child2: %d\n", count2);
			count2++;
		}
		else if(pid1 > 0 ){
			if(pid2 && pid2 > 0){
				printf("yayyyyyy");
			}
			//printf("Parent: %d\n", pcount);
			pcount++;
			if(fork_counter <2){
				pid2 = fork();
				fork_counter++;
			}
		}
		else{
			printf("something went wrong");
		}

	}
}*/	


