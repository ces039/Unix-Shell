/*Corrine Smith
 *CSCI 315
 *Lab1
 *8/29/17
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char* argv[]){

	if(argc != 5){
		printf("Incorrect number of parameters");
		return 0;
	}
	
	char* c;
	int i;
	float f;
	char* s;

	c = argv[1];
	i = atoi(argv[2]);
	f = atof(argv[3]);
	s = argv[4];

	printf("character: %s \n integer: %d \n float: %f \n string: %s\n", c, i, f, s);

	return 0;
}
	
		
		
		
