/* Corrine Smith
 * CSCI 315
 * Lab 2 Prelab
 * 9/5/17
 */

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>

#define BUFFER_SIZE 25
#define READ_END 0
#define WRITE_END 1

pid_t Fork(void){
	pid_t pid = fork();
	if (pid == -1){
		perror("Fork failed");
		exit(-1);
	}
}

int Pipe(int pipefd[2]){
	if(pipe(pipefd) == -1){
		perror("Pipe failed");
		exit(-1);
	}
}

int Read(int fd, void *buf, size_t count){
	if(read(fd, buf, count) == -1){
		perror("Read failed");
		exit(-1);
	}
}

int Write(int fd, const void *buf, size_t count){
	if(write(fd, buf, count) == -1){
		perror("Write failed");
		exit(-1);
	}
}

int main(void){
	char write_msg[BUFFER_SIZE] = "Greetings";
	char read_msg[BUFFER_SIZE];
	int fd[2];
	pid_t pid;

	// create the pipe
	Pipe(fd);
	
	//fork a child process
	pid = Fork();
	
	if(pid > 0){
		//parent process
		//close the unused end of the pipe
		close(fd[READ_END]);

		//write to the pipe
		int i = 0;
		while(write_msg[i] != '\0'){
			Write(fd[WRITE_END], &write_msg[i], 1);
			i++;
		}
		
		//close the write end of the pipe
		close(fd[WRITE_END]);
	}else{
		//child process
		//close the unused end of the pipe
		close(fd[WRITE_END]);

		//read from the pipe
		int i = 0;
		while(Read(fd[READ_END], &read_msg, 1) != 0){
			printf("read: %s\n", read_msg);
		}	
		//close the read end of the pipe
		close(fd[READ_END]);
	}
	return 0;
}
