/* Corrine Smith
 * CSCI 315
 * Lab2 Prelab
 * 9/6/17
 */

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>

int main(int argc, char *argv[]){
	char *str = (char *) malloc(20*sizeof(char));
	strcpy(str, "Hello World");
	pid_t pid;
	int status =0;
	
	printf("Parent originally sees str: %s\n", str);
	pid = fork();
	if(pid == 0){
		printf("Child originally sees str: %s\n", str);
		strcat(str, " this is the child process.\n");
		printf("Child now sees str: %s\n", str);
		exit(0);
	}
	else{
		wait(&status);
		printf("Parent now sees str: %s\n", str);
		exit(0);
	}
}
