/* Corrine Smith
 * CSCI 315
 * Lab 2 Prelab
 * 9/5/17
 */

#include <sys/types.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <ctype.h>
#include <stdbool.h>
#include <readline/readline.h>
#include <readline/history.h>

#define BUFFER_SIZE 50
#define READ_END 0
#define WRITE_END 1

pid_t Fork(void){
	pid_t pid = fork();
	if (pid == -1){
		perror("Fork failed");
		exit(-1);
	}
}

int Pipe(int pipefd[2]){
	if(pipe(pipefd) == -1){
		perror("Pipe failed");
		exit(-1);
	}
}

int Read(int fd, void *buf, size_t count){
	if(read(fd, buf, count) == -1){
		perror("Read failed");
		exit(-1);
	}
}

int Write(int fd, const void *buf, size_t count){
	if(write(fd, buf, count) == -1){
		perror("Write failed");
		exit(-1);
	}
}

int main(void){
	while(true){
		char *write_msg;
		char read_msg[BUFFER_SIZE] ="";
		int fd_pc[2];
		int fd_cp[2];

		pid_t pid;
		int status = 0;
	
		// create the pipes
		Pipe(fd_pc);
		Pipe(fd_cp);
	
		//fork a child process
		pid = Fork();

		if(pid > 0){
			//parent process
			//close the unused end of the pipe
			close(fd_pc[READ_END]);
			close(fd_cp[WRITE_END]);

			write_msg = readline("Enter a string: ");
			//write to the pipe
			int length = strlen(write_msg);

			Write(fd_pc[WRITE_END], &length, 4);
			Write(fd_pc[WRITE_END], write_msg, length);

			wait(&status);


			int count;
			Read(fd_cp[READ_END], &count, 4);
			Read(fd_cp[READ_END], &read_msg, count+1);
			printf("Read: %s\n", read_msg);
		
			close(fd_cp[READ_END]);
			close(fd_pc[WRITE_END]);

		}else{
			//child process
			//close the unused end of the pipe
			close(fd_pc[WRITE_END]);
			close(fd_cp[READ_END]);

			//read from the pipe
			int count;
			Read(fd_pc[READ_END], &count, 4);
			Read(fd_pc[READ_END], &read_msg, count+1);
			printf("read: %s\n", read_msg);
			char *token;
			token = strtok(read_msg, " ");
			char new_msg[BUFFER_SIZE] = "";
			while(token != NULL){
				strcat(new_msg, token);
				strcat(new_msg, " ");
				token = strtok(NULL, " ");
			
			}
			int new_length = strlen(new_msg);
			
			Write(fd_cp[WRITE_END], &new_length, 4);		
			Write(fd_cp[WRITE_END], &new_msg, strlen(new_msg)+1);
			
		
			close(fd_pc[READ_END]);
			close(fd_cp[WRITE_END]);
			exit(0);
		}
		free(write_msg);
		
	}
}
