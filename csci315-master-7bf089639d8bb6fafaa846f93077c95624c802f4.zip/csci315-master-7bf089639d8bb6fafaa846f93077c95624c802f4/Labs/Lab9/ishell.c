/* Corrine Smith
 * CSCI 315
 * Lab 9
 * 11/10/2017
 */

/* I attempted to implement the functionality to reproduce recent calls. However, was only successful with reproducing the most recent call. If the user wishes to repeat the last call they made, they simply enter prev at the shell prompt. The original thought was to implement a stack to keep track of the five most recent calls and push and pop on and off of the stack as commands were run. But, my pointers became very messy and started to overlap and affect each other and in turn the stack. So the current implementation just stores the most recent command as a string that is then used as the command when the user enters prev.*/

#include "wrappers.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <unistd.h>
#include <errno.h>
#include "stack.h"

int main(){
	char string[100];
	pid_t pid;
	int status = 0;
	char *command;
	char **args;
	//struct stack mystack;
	//stack_create(&mystack, 5);

	while(true){
		printf("ishell> ");
		fgets(string, 100, stdin);
		if(strcmp(string, "\n") == 0){
			fgets(string, 100, stdin);
			if(strcmp(string, "\n") == 0){
				args = (char **)calloc(6, 50*sizeof(char));
				args[0] = "ls";
				pid = Fork();
				if(pid == 0){
					execvp("ls", args);
				}
				else{
					Wait(&status);
				}
			}
		}
		char *input = strdup(string);
		
		/*if(strcmp(string, "prev\n") == 0 && mystack.size > 0){
			input = pop(&mystack);
                }
		else{
			input = strdup(string);
		}
		char *previous = strdup(input);
		push(&mystack, previous);*/
		char *token1;
		token1 = strtok_r(input, ";", &input);
		while(token1 != NULL){
			args = (char **)calloc(6, 50*sizeof(char));
			char *token;
			char *temp;
			token = strtok(token1, " ");	
			int count = 0;
			while(token != NULL){
				char *temp = strchr(token, '\n');
				if (temp)  *temp = 0;
				args[count] = token;
				count++;
				token = strtok(NULL, " ");			
			}
			command = args[0];
			args[count] = NULL;	
			if(strcmp(command, "cd") == 0){
				status = 0;
				if(args[1] == NULL){
					status = chdir(getenv("HOME"));
				}
				else{
					char *directory = args[1];
					status = chdir(directory);
				}
				if(status == 0){
					printf("directory change complete\n");
				}
				else{
					printf("unable to change directory: %s\n", strerror(errno));
				}
			}
			else if(strcmp(command, "exit") == 0){
				exit(0);
			}
			else{
				for(int i = 0; i < count; i++){
					strcat(args[i], "\0");
				}
				pid = Fork();
				if(pid > 0){
					//parent process
					Wait(&status);
				}
				else{
					//child process
					execvp(command, args);
				}
			}
		
			if(status == 0){
                                printf("ishell: program terminated successfully\n");
                        }
                	else{
                                printf("ishell: program terminated abnormally: %d\n", status);
                        }
			
			free(args);
			token1 = strtok_r(input, ";", &input);
		}
		//free(previous);
				
	}
}

