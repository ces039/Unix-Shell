/* Corrine Smith
 * CSCI 315
 * Lab 9
 * 11/10/2017
 */

#include "wrappers.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <pthread.h>
#include <unistd.h>

int main(){
	char string[50];
	char *input;
	pid_t pid;
	int status = 0;
	char *command;
	char **args;

	while(true){
		printf("ishell> ");
		fgets(string, 50, stdin);
		//printf("\nscan complete:  %s\n", string);
		char *token;
		char *temp;
		token = strtok(string, " ");		
		args = (char **)calloc(6, 50*sizeof(char));
		int count = 0;
		while(token != NULL){
		//	printf("string: %s\n", token);
			char *temp = strchr(token, '\n');
			if (temp)  *temp = 0;
			//strcat(token, "\0");
			args[count] = token;
		//	printf("arg %d allocated: %s\n", count, token);
			count++;
			token = strtok(NULL, " ");			
		}
		//printf("args complete, args[0]: %s\n", args[0]);
		command = args[0];
		//printf("count: %d\n", count);
		args[count] = NULL;
		//printf("current args[0]: %s\n", args[0]);

		if(strcmp(command, "cd") == 0){
			char *directory = "/csci315/Labs";
			int ret_val = chdir(directory);
			if(ret_val == 0){
				printf("directory change complete\n");
			}
			else{
				printf("error in directory change\n");
			}
		}
		else if(strcmp(command, "exit") == 0){
			exit(0);
		}
		else{
		for(int i = 0; i < count; i++){
			strcat(args[i], "\0");
		}
		pid = Fork();
		if(pid > 0){
			//parent process
			printf("waiting parent\n");
			fflush(stdout);
			Wait(&status);
		}
		else{
			//child process
			printf("exec to be executed\n");
			fflush(stdout);
			execvp(command, args);
			printf("exec executed\n");
			fflush(stdout);
			exit(0);
		}
		}
		free(args);		
	}
}	
