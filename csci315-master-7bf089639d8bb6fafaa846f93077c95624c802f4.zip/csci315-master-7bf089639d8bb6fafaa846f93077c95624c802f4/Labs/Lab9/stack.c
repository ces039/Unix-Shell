/* Corrine Smith
 * CSCI 315
 * Lab 9
 * 11/7/17
 */

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "stack.h"

int
stack_create(struct stack *s, int max){
	s->max = max;
	s->list = calloc(max, 100*sizeof(char));
	s->size = 0;
}

int
push(struct stack *s, char *string){
	int size = s->size;
	int max = s->max;
	char *copy = strdup(string);
	print(s);
	printf("size: %d\n", size);
	if(size == max-1){
		for(int i = 0; i < max-1; i++){
			printf("list: %s\n",s->list[i]);
			s->list[i] = s->list[i+1];
		}
		s->list[max-1] = copy;
	}
	else{
		s->list[size] = copy;
		s->size = size + 1;
		printf("newly added: %s\n", s->list[size]);
	}
	print(s);
	printf("size: %d\n", s->size);
	free(copy);
	return 0;
}

char *
pop(struct stack *s){
	print(s);
	char *string = s->list[s->size-1];
	s->size = s->size - 1;
	printf("pop string: %s\n", string);
	return string;
}

void print(struct stack *s){
	int size = s->size;
	int max = s->max;
	for(int i = size-1; i >= 0; i--){
		printf("stack #%d: %s\n", i, s->list[i]);
	}
}
