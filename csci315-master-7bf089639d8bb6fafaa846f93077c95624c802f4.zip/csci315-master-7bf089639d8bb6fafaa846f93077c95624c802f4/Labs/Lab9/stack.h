#ifndef _STACK_H_
#define _STACK_H_

#include <string.h>

struct stack{
	char **list;
	int size;
	int max;
};

int stack_create(struct stack *s, int max);

int push(struct stack *s, char *string);

char *pop(struct stack *s);

void print(struct stack *s);

#endif /* _STACK_H_ */
